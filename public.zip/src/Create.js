const Create = () => {
  return ( 
    <div className="title">
      <h2>Add a new Blog</h2>
    </div>
   );
}
 
export default Create;